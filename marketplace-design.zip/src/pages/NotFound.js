import { TabTitle } from "../utils/functions"

export default function NotFound() {
    TabTitle('Not Found, mdfk')
    return (
    <>
        <h1>404</h1>
    </>
    )
}