import { TabTitle } from "../utils/functions"

export default function Home() {
    TabTitle('Home')
    return <h1>Home </h1>
}