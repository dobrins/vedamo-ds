export const TabTitle = (title) => {
    return document.title = `${title} - VEDAMO`
}